import HomePage from '@/blocks/home';

export default function Page() {
  return <HomePage />;
}
