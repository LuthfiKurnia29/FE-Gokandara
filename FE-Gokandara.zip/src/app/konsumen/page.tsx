import KonsumenPage from '@/blocks/konsumen';

export default function Page() {
  return <KonsumenPage />;
}
