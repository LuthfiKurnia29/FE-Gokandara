export interface KonsumenData {
  no: number;
  name: string;
  id: string;
}
